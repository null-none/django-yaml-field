# django-yamlfield
Same as Django JSONField but represent it as YAML (internally stores as JSON)



```python

from django_yaml_field.fields import YAMLField


yaml = YAMLField()
```